# 👑 Monarque MD : Site de pairing

Les utilisateurs entrent leur numéro, reçoivent un **pairing code**, le saisissent dans WhatsApp, puis reçoivent un **Session ID** (sur le site et dans leur WhatsApp). Ils collent ce Session ID dans leur bot : plus de code à chercher dans la console.
Le tableau de bord `/admin` affiche le nombre d'appareils liés et en ligne.

## Déploiement (10 minutes)

1. **Mettre le projet sur GitHub** (dossier `monarque-pair-site`), puis sur vercel.com : *Add New → Project → Import*.
2. **Ajouter la base de données** : dans le projet Vercel, onglet *Storage → Create Database → Upstash Redis* (offre gratuite). Les variables `UPSTASH_REDIS_REST_URL` / `TOKEN` (ou `KV_REST_API_*`) sont ajoutées automatiquement.
3. **Variables d'environnement** (*Settings → Environment Variables*) :
   - `ADMIN_PASSWORD` : mot de passe de `/admin` (**obligatoire**, choisissez-le long)
4. **Déployer** (ou *Redeploy* après avoir ajouté les variables). Votre site est en ligne sur `https://votre-projet.vercel.app`.
5. **Configurer le bot** : dans `database/config.json` du bot, renseignez `"pairSiteUrl": "https://votre-projet.vercel.app"` puis redistribuez le bot.

`vercel.json` active déjà Fluid Compute et `maxDuration: 180` sur `/api/pair` (la liaison WhatsApp doit rester ouverte pendant la saisie du code).

## Côté utilisateur du bot

- Obtenir le Session ID sur le site.
- Le coller dans la variable d'environnement **`SESSION_ID`** du panel (Katabump, etc.) ou dans `database/config.json` → `"SESSION_ID"`.
- Démarrer le bot : il récupère sa session tout seul. Sans `SESSION_ID`, l'ancien mode (pairing code dans la console) fonctionne toujours.

## Comment sont comptés les appareils

| Compteur | Définition |
|---|---|
| **Appareils liés** | Numéros uniques ayant terminé un pairing via le site |
| **En ligne** | Bots ayant envoyé un signal de vie dans les 25 dernières minutes (envoi toutes les 10 min) |
| **Bot pas encore lancé** | Numéro lié, mais le bot n'a jamais envoyé de signal |

Seuls les bots démarrés avec un Session ID du site sont comptés « en ligne ».

## Sécurité et confidentialité

- Un Session ID est **à usage unique** : il est supprimé de la base dès que le bot le récupère (sinon il expire après 24 h). Le site ne garde ensuite que le numéro. `KEEP_SESSIONS=1` désactive ce comportement.
- Anti-abus : 6 demandes / 10 min par IP, 4 / heure par numéro, une seule demande simultanée par numéro (chaque demande envoie une notification sur le téléphone ciblé).
- `/admin` : cookie signé HttpOnly, 8 essais de connexion / 15 min. Les numéros sont masqués par défaut.

## Développement local

```bash
npm install
npx vercel dev      # sans base configurée, une mémoire locale est utilisée
```

## Limites à connaître

- La liaison dépend de la connexion Vercel → WhatsApp : si WhatsApp refuse temporairement les IP du datacenter, le site affichera une erreur et il suffira de réessayer.
- Offre gratuite Upstash : environ 100 bots actifs en simultané restent confortables (2 commandes Redis par signal de vie).
